<amp-sidebar id="sidebar"
             layout="nodisplay" width="200"
             side="right">
    <amp-img class="amp-close-image"
             src="../public/images/cancel-music.png"
             width="13"
             height="13"
             alt="close sidebar"
             on="tap:sidebar.close"
             role="button"
             tabindex="0"></amp-img>
    <ul class="menu-mobile">
        <li>
            <a href="#">Trang chủ</a>
        </li>
        <li>
            <a href="#">Hướng dẫn</a>
            <ul>
                <li><a href="#">Mỹ phẩm dưỡng da</a></li>
                <li><a href="#">Mỹ phẩm trang điểm</a></li>
                <li><a href="#">Thành phần mỹ phẩm</a></li>
            </ul>
        </li>
        <li>
            <a href="#">Son</a>
            <ul>
                <li><a href="#">Son dưỡng</a></li>
                <li><a href="#">Son bóng</a></li>
                <li><a href="#">Son tint</a></li>
                <li><a href="#">Son kem</a></li>
                <li><a href="#">Son lì</a></li>
                <li><a href="#">Son thỏi</a></li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(url('tintuc')); ?>">Mỹ phẩm</a>
        </li>
        <li>
            <a href="#">Chúng tôi</a>
        </li>
    </ul>
</amp-sidebar>
<div class="container-fluid ">
    <div class="row cang-le header">
        <div class="col-md-2">
            <amp-img class="logo-begido" src="<?php echo e(asset("images/begido-300x100.png")); ?>" height="1" width="1" layout="responsive"></amp-img>
        </div>
        <div class="col-md-8">
            <ul class="menu-destop">
                <li>
                    <a href="#">Trang chủ</a>
                </li>
                <li>
                    <a href="#">Hướng dẫn</a>
                    <ul>
                        <li><a href="#">Mỹ phẩm dưỡng da</a></li>
                        <li><a href="#">Mỹ phẩm trang điểm</a></li>
                        <li><a href="#">Thành phần mỹ phẩm</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Son</a>
                    <ul>
                        <li><a href="#">Son dưỡng</a></li>
                        <li><a href="#">Son bóng</a></li>
                        <li><a href="#">Son tint</a></li>
                        <li><a href="#">Son kem</a></li>
                        <li><a href="#">Son lì</a></li>
                        <li><a href="#">Son thỏi</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(url('tintuc')); ?>">Mỹ phẩm</a>
                </li>
                <li>
                    <a href="#">Chúng tôi</a>
                </li>
            </ul>
        </div>
        <div class="col-md-2">
            <amp-img role="button" tabindex="0" on="tap:sidebar.toggle" class="open-sidebar" src="../public/images/menu.png" height="20" width="20">
            </amp-img>
            <amp-img class="search-icon" src="../public/images/search.png" height="20" width="20">
            </amp-img>
        </div>
    </div>
</div>