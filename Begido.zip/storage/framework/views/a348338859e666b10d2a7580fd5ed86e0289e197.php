<!doctype html>
<html amp lang="en">
<head>
    <meta charset="utf-8">
    <title>Cititime</title>
    <link rel="canonical" href="#">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
    <script async src="https://cdn.ampproject.org/v0.js"></script>
    <script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes  -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
    <style amp-custom>
        .logo-thuong-hieu{
            height: 200px;
            width: 200px;
        }
        .logo-begido{
            width: 100px;
            height:33px;
        }
        .container {
            width: 100%;
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto;
        }
        .container-fluid {
            width: 100%;
            padding-right: 10px;
            padding-left: 10px;
            margin-right: auto;
            margin-left: auto;
        }
        .row {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;
        }
        .open-sidebar{
            cursor: context-menu;
        }
        @media (min-width: 480px) {
            .container {
                max-width: 540px;
            }
            amp-sidebar {
                width: 300px;
                padding-right: 10px;
            }
            .amp-sidebar-image {
                line-height: 100px;
                vertical-align:middle;
            }
            .amp-close-image {
                top: 15px;
                left: 275px;
                cursor: pointer;
            }
            .menu-mobile li {
                margin-top: 20px;
                margin-left: 10px;
                margin-right: 10px;
                list-style: none;
            }
            .menu-mobile li a{
                text-decoration: none;
            }
        }
        @media (min-width: 768px) {
            .container {
                max-width: 720px;
            }
            .menu-destop {
                list-style: none;
                padding: 0;
                margin: 0;
                display: block;
                z-index: 999;
            }
            .menu-destop li {
                display: block;
                position: relative;
                float: left;
            }
            .menu-destop li ul {
                display: none;
                z-index: 999;
            }
            .menu-destop li a {
                display: block;
                padding: 10px;
                text-decoration: none;
                white-space: nowrap;
                color: #000;
                font-size: 13px;
                text-transform: uppercase;
                font-weight: bold;
            }
            .menu-destop li a:hover {
                color: #000;
            }
            .menu-destop li:hover > ul {
                display: block;
                position: absolute;
            }
            .menu-destop li:hover li {
                float: none;
                border-radius: 2px;
            }
            .menu-destop li:hover a { background: #fff; }
            .menu-destop li:hover li a:hover { background: #fff; }
            .menu-destop li ul li {
                border-top: 0;
                border-radius: 2px;
                padding: 2px 10px;
            }
            .menu-destop ul ul {
                left: 100%;
                top: 0;
            }
            .menu-destop ul:before,
            .menu-destop ul:after {
                content: " ";
                display: table;
            }
            .col-md-2 {
                 -ms-flex: 0 0 16.666667%;
                 flex: 0 0 16.666667%;
                 max-width: 16.666667%;
             }
            .col-md-8 {
                -ms-flex: 0 0 66.666667%;
                flex: 0 0 66.666667%;
                max-width: 66.666667%;
            }
        }
        @media (min-width: 992px) {
            .container {
                max-width: 960px;
            }
        }
        @media (min-width: 1200px) {
            .container {
                max-width: 1140px;
            }
        }
    </style>
</head>
<body>
<amp-sidebar id="sidebar"
             layout="nodisplay" width="200"
             side="right">
    <amp-img class="amp-close-image"
             src="../public/images/cancel-music.png"
             width="13"
             height="13"
             alt="close sidebar"
             on="tap:sidebar.close"
             role="button"
             tabindex="0"></amp-img>
    <ul class="menu-mobile">
        <li>
            <a href="#">Trang chủ</a>
        </li>
        <li>
            <a href="#">Hướng dẫn</a>
            <ul>
                <li><a href="#">Mỹ phẩm dưỡng da</a></li>
                <li><a href="#">Mỹ phẩm trang điểm</a></li>
                <li><a href="#">Thành phần mỹ phẩm</a></li>
            </ul>
        </li>
        <li>
            <a href="#">Son</a>
            <ul>
                <li><a href="#">Son dưỡng</a></li>
                <li><a href="#">Son bóng</a></li>
                <li><a href="#">Son tint</a></li>
                <li><a href="#">Son kem</a></li>
                <li><a href="#">Son lì</a></li>
                <li><a href="#">Son thỏi</a></li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(url('tintuc')); ?>">Mỹ phẩm</a>
        </li>
        <li>
            <a href="#">Chúng tôi</a>
        </li>
    </ul>
</amp-sidebar>
<div class="container-fluid background-header">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <amp-img class="logo-begido" src="<?php echo e(asset("images/begido-300x100.png")); ?>" height="1" width="1" layout="responsive"></amp-img>
            </div>
            <div class="col-md-8">
                <ul class="menu-destop">
                    <li>
                        <a href="#">Trang chủ</a>
                    </li>
                    <li>
                        <a href="#">Hướng dẫn</a>
                        <ul>
                            <li><a href="#">Mỹ phẩm dưỡng da</a></li>
                            <li><a href="#">Mỹ phẩm trang điểm</a></li>
                            <li><a href="#">Thành phần mỹ phẩm</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Son</a>
                        <ul>
                            <li><a href="#">Son dưỡng</a></li>
                            <li><a href="#">Son bóng</a></li>
                            <li><a href="#">Son tint</a></li>
                            <li><a href="#">Son kem</a></li>
                            <li><a href="#">Son lì</a></li>
                            <li><a href="#">Son thỏi</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(url('tintuc')); ?>">Mỹ phẩm</a>
                    </li>
                    <li>
                        <a href="#">Chúng tôi</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-2">
                <amp-img role="button" tabindex="0" on="tap:sidebar.toggle" class="open-sidebar" src="../public/images/menu.png" height="15" width="15">
                </amp-img>
                <amp-img class="search-icon" src="../public/images/search.png" height="15" width="15">
                </amp-img>
            </div>
        </div>
    </div>
    <hr>
</div>

<div class="container-fluid">
    <div class="row">
        <?php for($i = 0; $i < 12; $i++): ?>
            <?php if( $i % 2 == 0 ): ?>
                <div class="col-md-2 col-sm-3 col-6">
                    <amp-img class="logo-thuong-hieu" src="<?php echo e(asset("images/logo-casio.jpg")); ?>" height="1" width="1" layout="responsive"></amp-img>
                </div>
            <?php else: ?>
                <div class="col-md-2 col-sm-3 col-6">
                    <amp-img class="logo-thuong-hieu" src="<?php echo e(asset("images/logo-citizen.jpg")); ?>" height="1" width="1" layout="responsive"></amp-img>
                </div>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
</div>
</body>
</html>