<?php
Route::get('/amp', function () {
    return view('master-amp');
});

Route::get('/', function () {
    return view('tin-tuc.view-trang-chu');
});